# hydroxai

HydroxAI SDK for compliance scanning and chatbot evaluation.

Quickstart:

```python
from hydroxai import compliance

scanner = compliance.Scanner()
result = scanner.scan_chatbot("https://example.com")
print(result)
```
