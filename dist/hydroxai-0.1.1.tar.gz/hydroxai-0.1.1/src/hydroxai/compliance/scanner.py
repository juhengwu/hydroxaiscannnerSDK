from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional


@dataclass(slots=True)
class ScanResult:
    ok: bool
    summary: str
    details: Dict[str, Any]


class Scanner:
    def __init__(self, *, timeout: float = 60.0) -> None:
        self.timeout = timeout

    def scan_chatbot(self, url: str) -> ScanResult:
        return ScanResult(ok=True, summary=f"Scanned chatbot at {url}", details={"url": url})

    def scan_api(
        self,
        *,
        url: str,
        method: str = "POST",
        headers: Optional[Mapping[str, str]] = None,
        body: Optional[Any] = None,
    ) -> ScanResult:
        return ScanResult(
            ok=True,
            summary=f"Scanned API {method.upper()} {url}",
            details={"url": url, "method": method, "headers": dict(headers or {}), "body": body},
        )

    def scan_function(self, main_params: Any, *, function_code: str) -> ScanResult:
        return ScanResult(
            ok=True,
            summary=f"Scanned function {function_code}",
            details={"params": main_params, "function_code": function_code},
        )

    def scan_agent(self) -> ScanResult:
        return ScanResult(ok=False, summary="scan_agent not implemented", details={})

    def scan_mcp(self) -> ScanResult:
        return ScanResult(ok=False, summary="scan_mcp not implemented", details={})

